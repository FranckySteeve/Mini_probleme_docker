import pandas as pd

df = pd.read_csv('country_table.csv')

apercu_html = df.head().to_html(classes='table table-striped', border=0)
stats_html = df.describe().to_html(classes='table table-bordered', border=0)

# HTML
html_content = f"""
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Statistiques des Étudiants</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="p-5">
    <h1 class="mb-4">Aperçu du fichier CSV</h1>
    {apercu_html}
    <h2 class="mt-5">Descriptions Statistiques</h2>
    {stats_html}
</body>
</html>
"""

# genere html dans static
with open("static/index.html", "w", encoding="utf-8") as f:
    f.write(html_content)


print("✅ Fichier HTML généré avec succès.")
